import tkinter as tk, time

def run(win, parent_app=None):
    win.geometry("360x640")
    frame = tk.Frame(win)
    frame.pack(fill="both", expand=True)
    lbl = tk.Label(frame, text=time.strftime("%I:%M:%S %p"), font=("Helvetica",36))
    lbl.pack(expand=True)
    def tick():
        lbl.config(text=time.strftime("%I:%M:%S %p"))
        win.after(200, tick)
    tick()
