import tkinter as tk, urllib.request, json

def run(win, parent_app=None):
    win.geometry("360x640")
    frame = tk.Frame(win)
    frame.pack(fill="both", expand=True)
    tk.Label(frame, text="Weather", font=("Helvetica",18)).pack(pady=8)
    txt = tk.Text(frame, height=10)
    txt.pack(fill="both", expand=True, padx=8, pady=8)
    try:
        url = "https://api.open-meteo.com/v1/forecast?latitude=43.7&longitude=-79.4&current_weather=true"
        with urllib.request.urlopen(url, timeout=6) as r:
            data = json.loads(r.read().decode())
            cw = data.get("current_weather", {})
            txt.insert("end", f"Temperature: {cw.get('temperature')} C\nWind: {cw.get('windspeed')} km/h\n")
    except Exception:
        txt.insert("end", "Offline or API blocked. Sample: 22 C, Sunny")
